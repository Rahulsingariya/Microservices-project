# Microservices Demo (User, Product, Order) - Dockerized

This project contains three Flask microservices:
- **user-service** (port 5001)
- **product-service** (port 5002)
- **order-service** (port 5003) — validates user and product IDs by calling the other services

Run all services with Docker Compose:
```bash
docker-compose up --build
```

Access endpoints once running:
- User service: http://localhost:5001/users
- Product service: http://localhost:5002/products
- Order service: http://localhost:5003/orders

Notes:
- Order service performs validation by calling the other services using container hostnames (user-service, product-service). Using docker-compose is recommended so container DNS resolution works.
- All services store data in-memory (no persistence). You can extend them to use a database later.
