from flask import Flask, jsonify, request
import requests

app = Flask(__name__)

# In-memory storage for orders
orders = []
order_id_counter = 1

@app.route('/orders', methods=['GET'])
def get_orders():
    """Get all orders"""
    return jsonify({'orders': orders, 'count': len(orders)}), 200

@app.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    """Get a specific order by ID"""
    order = next((o for o in orders if o['id'] == order_id), None)
    if order:
        return jsonify(order), 200
    return jsonify({'error': 'Order not found'}), 404

@app.route('/orders', methods=['POST'])
def create_order():
    """Create a new order"""
    global order_id_counter
    data = request.get_json()
    
    if not data or 'user_id' not in data or 'product_id' not in data or 'quantity' not in data:
        return jsonify({'error': 'Missing required fields: user_id, product_id, quantity'}), 400
    
    # Verify user exists (call user-service)
    try:
        user_response = requests.get(f'http://user-service:5001/users/{data["user_id"]}', timeout=5)
        if user_response.status_code != 200:
            return jsonify({'error': 'User not found'}), 404
    except requests.exceptions.RequestException:
        return jsonify({'error': 'User service unavailable'}), 503
    
    # Verify product exists (call product-service)
    try:
        product_response = requests.get(f'http://product-service:5002/products/{data["product_id"]}', timeout=5)
        if product_response.status_code != 200:
            return jsonify({'error': 'Product not found'}), 404
        product = product_response.json()
    except requests.exceptions.RequestException:
        return jsonify({'error': 'Product service unavailable'}), 503
    
    order = {
        'id': order_id_counter,
        'user_id': data['user_id'],
        'product_id': data['product_id'],
        'quantity': data['quantity'],
        'total_price': product['price'] * data['quantity'],
        'status': 'pending'
    }
    orders.append(order)
    order_id_counter += 1
    
    return jsonify(order), 201

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'order-service'}), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5003)
