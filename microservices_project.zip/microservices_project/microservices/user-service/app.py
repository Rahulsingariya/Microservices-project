from flask import Flask, jsonify, request

app = Flask(__name__)

# In-memory storage for users
users = [
    {'id': 1, 'name': 'John Doe', 'email': 'john@example.com', 'role': 'customer'},
    {'id': 2, 'name': 'Jane Smith', 'email': 'jane@example.com', 'role': 'customer'}
]
user_id_counter = 3

@app.route('/users', methods=['GET'])
def get_users():
    """Get all users"""
    return jsonify({'users': users, 'count': len(users)}), 200

@app.route('/users/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Get a specific user by ID"""
    user = next((u for u in users if u['id'] == user_id), None)
    if user:
        return jsonify(user), 200
    return jsonify({'error': 'User not found'}), 404

@app.route('/users', methods=['POST'])
def create_user():
    """Create a new user"""
    global user_id_counter
    data = request.get_json()
    
    if not data or 'name' not in data or 'email' not in data:
        return jsonify({'error': 'Missing required fields: name, email'}), 400
    
    user = {
        'id': user_id_counter,
        'name': data['name'],
        'email': data['email'],
        'role': data.get('role', 'customer')
    }
    users.append(user)
    user_id_counter += 1
    
    return jsonify(user), 201

@app.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """Update a user"""
    user = next((u for u in users if u['id'] == user_id), None)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    data = request.get_json()
    if 'name' in data:
        user['name'] = data['name']
    if 'email' in data:
        user['email'] = data['email']
    if 'role' in data:
        user['role'] = data['role']
    
    return jsonify(user), 200

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'user-service'}), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
