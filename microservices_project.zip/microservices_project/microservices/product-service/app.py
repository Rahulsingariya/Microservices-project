from flask import Flask, jsonify, request

app = Flask(__name__)

# In-memory storage for products
products = [
    {'id': 1, 'name': 'Laptop', 'price': 999.99, 'stock': 50},
    {'id': 2, 'name': 'Mouse', 'price': 29.99, 'stock': 200},
    {'id': 3, 'name': 'Keyboard', 'price': 79.99, 'stock': 150}
]
product_id_counter = 4

@app.route('/products', methods=['GET'])
def get_products():
    """Get all products"""
    return jsonify({'products': products, 'count': len(products)}), 200

@app.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get a specific product by ID"""
    product = next((p for p in products if p['id'] == product_id), None)
    if product:
        return jsonify(product), 200
    return jsonify({'error': 'Product not found'}), 404

@app.route('/products', methods=['POST'])
def create_product():
    """Create a new product"""
    global product_id_counter
    data = request.get_json()
    
    if not data or 'name' not in data or 'price' not in data or 'stock' not in data:
        return jsonify({'error': 'Missing required fields: name, price, stock'}), 400
    
    product = {
        'id': product_id_counter,
        'name': data['name'],
        'price': data['price'],
        'stock': data['stock']
    }
    products.append(product)
    product_id_counter += 1
    
    return jsonify(product), 201

@app.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    """Update a product"""
    product = next((p for p in products if p['id'] == product_id), None)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    
    data = request.get_json()
    if 'name' in data:
        product['name'] = data['name']
    if 'price' in data:
        product['price'] = data['price']
    if 'stock' in data:
        product['stock'] = data['stock']
    
    return jsonify(product), 200

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'product-service'}), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5002)
